export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBi2rvlN5Fy7vKWB7cnKBI48Aazirsnq_M",
    authDomain: "mysample-739c4.firebaseapp.com",
    databaseURL: "https://mysample-739c4.firebaseio.com",
    projectId: "mysample-739c4",
    storageBucket: "mysample-739c4.appspot.com",
    messagingSenderId: "346832656889"

}
};
