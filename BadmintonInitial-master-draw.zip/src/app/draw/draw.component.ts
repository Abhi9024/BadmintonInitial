import { Component, OnInit } from '@angular/core';
import { PlayerService } from 'app/services/player.service';
import { DrawService } from 'app/services/draw.service';
import { IPlayer } from 'app/models/IPlayer';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-draw',
  templateUrl: './draw.component.html',
  styleUrls: ['./draw.component.css']
})
export class DrawComponent implements OnInit {
  playersCount : number ;
  drawArray : any[];

  constructor(private playerService: PlayerService, private drawService: DrawService) { }
  
  ngOnInit() {
   this.getPlayersCount();
  }

  getPlayersCount(){
    this.playerService.getPlayers("/Players").
    subscribe((result:IPlayer[]) => {
      this.playersCount = result.length;
      this.getDrawDetails();
    },
    error => {console.log(error)}
  ); 
  }

  getDrawDetails(){
   this.drawArray =  this.drawService.getDraw(this.playersCount);
   console.log("length: " + this.playersCount);
   console.log(this.drawArray);
  }

  
}
