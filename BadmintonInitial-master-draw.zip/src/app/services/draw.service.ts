import { Injectable } from '@angular/core';

@Injectable()
export class DrawService {

  constructor() { }

  getDraw(numberOfPlayers: number): any[]{
    let rounds = (Math.log(numberOfPlayers)/Math.log(2))-1;
    let pls = [1,2];
    for(var i=0;i<rounds;i++){
      pls = this.nextLayer(pls);
    }
    return pls;
  }

 nextLayer(pls:any[]):any[]{
    let out=[];
    let length = pls.length*2+1;
    pls.forEach(function(d){
      out.push(d);
      out.push(length-d);
    });
    return out;
  }

}
