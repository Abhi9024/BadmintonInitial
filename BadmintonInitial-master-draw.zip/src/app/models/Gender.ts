export enum Gender{
    male=1,
    female=2
}