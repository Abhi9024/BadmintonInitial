import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
import { IPlayer } from 'app/models/IPlayer';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class DrawService {

  constructor(private db:AngularFireDatabase) { }


  getDrawDetails(path:string,queryData:number):Observable<any[]>{
    return this.db.list(path, query => {
      let q = query.orderByChild('roundNo').equalTo(queryData);
      return q;
   }).valueChanges();
  }


  getDraw(numberOfPlayers: number): any[]{
    let rounds = (Math.log(numberOfPlayers)/Math.log(2))-1;
    let pls = [1,2];
    for(var i=0;i<rounds;i++){
      pls = this.nextLayer(pls);
    }
    return pls;
  }

 nextLayer(pls:any[]):any[]{
    let out=[];
    let length = pls.length*2+1;
    pls.forEach(function(d){
      out.push(d);
      out.push(length-d);
    });
    return out;
  }

}
