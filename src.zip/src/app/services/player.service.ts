import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { Observable } from 'rxjs/Observable';
import { IPlayer } from 'app/models/IPlayer';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class PlayerService {

  constructor(private db:AngularFireDatabase){
  }
  
  getPlayers(path):Observable<IPlayer[]>{
      return this.db.list(path).valueChanges();
  }
}
