export interface ICourt{
    id: string;
    desc: string;
}