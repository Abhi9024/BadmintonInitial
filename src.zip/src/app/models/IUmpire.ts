export interface IUmpire{
    name: string;
    id: string;
    email: string;
    address: string;
    phone: number;
}